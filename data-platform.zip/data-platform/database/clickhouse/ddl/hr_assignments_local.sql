CREATE TABLE IF NOT EXISTS locals.hr_assignments_local ON CLUSTER adqm
(
    obj_id           Int32,
    emp_area_code    LowCardinality(String),
    emp_subarea_code LowCardinality(String),
    start_dt         Date,
    end_dt           Date,
    insert_dt        DateTime DEFAULT now()
)
ENGINE = ReplicatedMergeTree(
    '/clickhouse/tables/{adqm_shard}/{database}/{table}',
    '{adqm_replica}'
)
PARTITION BY toYYYYMM(start_dt)
ORDER BY (obj_id, start_dt)
SETTINGS index_granularity = 8192;
