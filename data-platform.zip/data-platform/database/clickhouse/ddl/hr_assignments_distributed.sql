CREATE TABLE IF NOT EXISTS hr.hr_assignments ON CLUSTER adqm
AS locals.hr_assignments_local
ENGINE = Distributed(
    'adqm',
    'locals',
    'hr_assignments_local',
    cityHash64(obj_id)
);
