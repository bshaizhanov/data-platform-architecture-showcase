CREATE TABLE IF NOT EXISTS analytics.fct_downtimes_hourly
(
    metric_date Date,
    event_time DateTime('Asia/Almaty'),
    unit_name LowCardinality(String),
    param_code String,
    plan_value Float64,
    fact_value Float64,
    sign Int8 DEFAULT 1,
    version UInt64
)
ENGINE = ReplacingMergeTree(version)
PARTITION BY toYYYYMM(metric_date)
ORDER BY (unit_name, param_code, event_time)
SETTINGS index_granularity = 8192;
