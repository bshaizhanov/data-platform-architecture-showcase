-- Streaming insert through the distributed interface
INSERT INTO hr.hr_assignments (obj_id, emp_area_code, emp_subarea_code, start_dt, end_dt)
VALUES (123, '1000', '1001', '2025-10-01', '2025-12-31');
-- Parallelized analytical query
SELECT * FROM hr.hr_assignments WHERE obj_id = 123;
-- Asynchronous cascading delete at the level of local cluster segments
ALTER TABLE locals.toir_material_local ON CLUSTER adqm
DELETE WHERE left(matl_group, 2) = '06';
