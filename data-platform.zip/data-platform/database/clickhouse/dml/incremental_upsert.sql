INSERT INTO analytics.fct_downtimes_hourly 
    (metric_date, event_time, unit_name, param_code, plan_value, fact_value, version)
SELECT
    toDate(raw_timestamp) AS metric_date,
    toDateTime(raw_timestamp, 'Asia/Almaty') AS event_time,
    assumeNotNull(unit_name) AS unit_name,
    param_code,
    toFloat64(plan_string) AS plan_value,
    toFloat64(fact_string) AS fact_value,
    toUInt64(now()) AS version
FROM sa.ext_s3_landing_raw_data
WHERE metric_date >= today() - INTERVAL '3 day'
SETTINGS max_insert_block_size = 100000;
