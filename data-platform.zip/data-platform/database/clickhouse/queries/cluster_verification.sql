-- Check that local tables physically exist on every cluster node
SELECT cluster, shard_num, replica_num, host_name, database, name
FROM system.clusters c
JOIN clusterAllReplicas('adqm', system.tables) t ON c.host_name = t.hostName()
WHERE t.database = 'locals' AND t.name = 'hr_assignments_local'
ORDER BY shard_num, replica_num;
-- Check the total number of active rows per replica
SELECT 'LOCAL sum' AS kind, sum(rows) AS rows
FROM clusterAllReplicas('adqm', system.parts)
WHERE database='locals' AND table='hr_assignments_local' AND active;
-- Validate data volume distribution across cluster shards (skew check)
SELECT shardNum() AS shard, count() 
FROM hr.hr_assignments 
GROUP BY shard;
