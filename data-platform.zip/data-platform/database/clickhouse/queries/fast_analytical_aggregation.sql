SELECT
    unit_name,
    param_code,
    sum(plan_value) AS total_plan_hours,
    sum(fact_value) AS total_fact_hours,
    round(if(total_plan_hours > 0, (total_fact_hours / total_plan_hours) * 100, 0), 2) AS variance_percentage
FROM analytics.fct_downtimes_hourly
FINAL
WHERE metric_date BETWEEN toStartOfMonth(today()) AND today()
GROUP BY unit_name, param_code
HAVING total_fact_hours > 0
ORDER BY variance_percentage DESC
LIMIT 500;
