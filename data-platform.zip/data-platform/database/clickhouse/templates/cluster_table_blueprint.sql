-- 1) Create a unified local replicated storage table
CREATE TABLE IF NOT EXISTS locals.{name}_local ON CLUSTER adqm
(
    id UInt64,
    updated_at DateTime,
    data_payload String
)
ENGINE = ReplicatedMergeTree(
  '/clickhouse/tables/{adqm_shard}/{database}/{table}',
  '{adqm_replica}'
)
PARTITION BY toYYYYMM(updated_at)
ORDER BY (id);
-- 2) Create a distributed projection of the business layer
CREATE TABLE IF NOT EXISTS {biz_db}.{name} ON CLUSTER adqm
AS locals.{name}_local
ENGINE = Distributed('adqm', 'locals', '{name}_local', cityHash64(id));
-- 3) Synchronous data cleanup across the cluster
TRUNCATE TABLE locals.{name}_local ON CLUSTER adqm;
-- 4) Safe cascading removal of the entity from the cluster
DROP TABLE locals.{name}_local ON CLUSTER adqm SYNC;
