
CREATE TABLE core.fct_platform_events (
    event_hk UUID NOT NULL, 
    event_timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    unit_id VARCHAR(50) NOT NULL, 
    param_code VARCHAR(100) NOT NULL, 
    plan_value NUMERIC(18, 4), 
    fact_value NUMERIC(18, 4), 
    hash_diff UUID NOT NULL, 
    load_date TIMESTAMP DEFAULT now()
)
WITH (
    appendonly=true,
    orientation=column, 
    compresstype=zstd, 
    compresslevel=4
)
DISTRIBUTED BY (event_hk) 
PARTITION BY RANGE (event_timestamp) (
    START (DATE '2024-01-01') INCLUSIVE
    END (DATE '2025-01-01') EXCLUSIVE
    EVERY (INTERVAL '1 month'),
    DEFAULT PARTITION outlier_events
);

-- Create an index to speed up analytical (cube) queries
CREATE INDEX idx_fct_platform_events_search 
ON core.fct_platform_events (unit_id, param_code);
