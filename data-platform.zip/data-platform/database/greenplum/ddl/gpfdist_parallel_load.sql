
CREATE EXTERNAL TABLE sa.ext_gpfdist_file_extract (
    record_dt DATE,
    unit_name VARCHAR(100),
    metric_code VARCHAR(100),
    metric_value NUMERIC(18, 4)
)
LOCATION (
    'gpfdist://gpfdist-worker-01.internal_domain_placeholder:8081/file_hub_data/*.csv',
    'gpfdist://gpfdist-worker-02.internal_domain_placeholder:8081/file_hub_data/*.csv'
)
FORMAT 'CSV' (
    HEADER
    DELIMITER ';'
    QUOTE '"'
    NULL 'NULL'
)
ENCODING 'UTF8'
LOG ERRORS SEGMENT REJECT LIMIT 1000 ROWS;
