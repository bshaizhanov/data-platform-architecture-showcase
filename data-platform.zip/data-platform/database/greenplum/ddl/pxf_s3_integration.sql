CREATE EXTERNAL TABLE sa.ext_s3_landing_raw_data (
    raw_timestamp TEXT,
    unit_name TEXT,
    metric_code TEXT,
    value_string TEXT
)
LOCATION (
    'pxf://data-transfer-bucket/landing/raw_data/?PROFILE=s3:text&SERVER=s3_netapp_placeholder'
)
FORMAT 'TEXT' (
    delimiter = ',' 
    null = '' 
    escape = 'none'
)
SETTINGS (
    encoding = 'UTF8'
)
LOG ERRORS SEGMENT REJECT LIMIT 10 PERCENT;
