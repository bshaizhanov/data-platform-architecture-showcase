#!/bin/bash
# SCRIPT FOR ORCHESTRATION AND AUTOMATIC RECOVERY OF DATABASE SEGMENTS
set -e
# Anonymized initialization of the Greenplum system environment
source /usr/local/greenplum-db/greenplum_path.sh
export MASTER_DATA_DIRECTORY=/data/dwh/master/gpseg-1
LOG_FILE="/home/gpadmin/scripts/logs/segment_recovery_$(date +%Y%m%d).log"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting scheduled segment health check..." >> "$LOG_FILE"
# 1. Check for failed segments ('down' status in the configuration)
# The gpstate utility is used to detect mirroring failures
FAILED_SEG_COUNT=$(gpstate -e | grep -c "Segment Matrix" || true)
if [ "$FAILED_SEG_COUNT" -gt 0 ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] WARNING: Failed cluster segments detected. Starting automatic recovery..." >> "$LOG_FILE" 
    # 2. Attempt incremental segment recovery
    # The -a option disables interactive prompts so the script can run from cron
    if gprecoversegments -a -F >> "$LOG_FILE" 2>&1; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] gprecoversegments started successfully." >> "$LOG_FILE"
        # Wait for data synchronization (rebalancing) to finish
        sleep 60
        # 3. Return segments to their original roles (rebalance after recovery)
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting segment rebalance to restore the optimal configuration..." >> "$LOG_FILE"
        gprecoversegments -r -a >> "$LOG_FILE" 2>&1
    else
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] CRITICAL ERROR: Automatic incremental recovery failed." >> "$LOG_FILE"
        # Integration with the platform alerting subsystem (notify administrators)
        exit 1
    fi
else
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Check completed: all segments of the distributed storage are operating normally." >> "$LOG_FILE"
fi
exit 0
