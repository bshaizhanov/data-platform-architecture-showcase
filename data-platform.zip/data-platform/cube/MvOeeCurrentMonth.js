cube(`MvOeeCurrentMonth`, {
  sql: `
    SELECT
      sapnumber,
      equipment_name,
      startdate,
      enddate,
      update_dt,
      deviation_oee_flag,
      deviation_production_flag,
      directoeeplan,
      directoeefact,
      deviation_oee,
      productionplan,
      productionfact,
      deviation_production
    FROM schema_name.view_name
  `,
  dataSource: `greenplum_dwh`,
  dimensions: {
    id: {
      sql: `CONCAT(sapnumber::text, '-', startdate::text)`,
      type: `string`,
      primaryKey: true
    },
    sapnumber: {
      sql: `sapnumber`,
      type: `number`
    },
    equipment_name: {
      sql: `equipment_name`,
      type: `string`
    },
    startdate: {
      sql: `startdate`,
      type: `time`
    },
    enddate: {
      sql: `enddate`,
      type: `time`
    },
    update_dt: {
      sql: `update_dt`,
      type: `time`
    },
    deviation_oee_flag: {
      sql: `deviation_oee_flag`,
      type: `number`
    },
    deviation_production_flag: {
      sql: `deviation_production_flag`,
      type: `number`
    }
  },
  measures: {
    count: {
      type: `count`
    },
    directoeeplan: {
      sql: `directoeeplan`,
      type: `sum`
    },
    directoeefact: {
      sql: `directoeefact`,
      type: `sum`
    },
    deviation_oee: {
      sql: `deviation_oee`,
      type: `sum`
    },
    productionplan: {
      sql: `productionplan`,
      type: `sum`
    },
    productionfact: {
      sql: `productionfact`,
      type: `sum`
    },
    deviation_production: {
      sql: `deviation_production`,
      type: `sum`
    }
  },
  preAggregations: {
    main: {
      type: `rollup`,
      measureReferences: [
        count,
        directoeeplan,
        directoeefact,
        deviation_oee,
        productionplan,
        productionfact,
        deviation_production
      ],
      dimensionReferences: [
        equipment_name
      ],
      timeDimensionReference: startdate,
      granularity: `day`,
      refreshKey: {
        sql: `SELECT MAX(update_dt) FROM schema_name.view_name`
      }
    }
  }
});
