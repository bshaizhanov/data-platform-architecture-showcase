# Data Platform: Source Code Sample

An anonymized, representative fragment of the source code of an enterprise **Data Platform**: ingestion and orchestration, streaming, storage, semantic/BI layer, data governance, logging, and cluster operations.

> **Note:** All instance identifiers, passwords, tokens, API keys, internal IP addresses, hostnames, and personal data have been removed or replaced with placeholders. Names of some tables and variables are abstracted. This is a sample, not a ready-to-run deployment.

## Repository Structure

| Layer | Path | Description |
|---|---|---|
| Orchestration and ELT | `dags/source_to_target_loader.py` | Airflow DAG: dynamic transfer, validation, and incremental reload from a relational DB to ClickHouse via object storage |
| | `dags/astpi_edc_load.py` | Incremental load from an external API into the analytical core with hash-based UPSERT |
| | `dags/enviro_sap_loader.py` | SAP integration: automatic pipeline assembly and materialized view refresh |
| | `gitlab-ci.airflow-pipeline.yml` | CI for DAG testing, validation, and merge request approvals |
| Streaming | `clickhouse_kafka_pipeline_template.sql` | Template for streaming CDC load from Kafka into ClickHouse |
| Storage | `database/greenplum/` | Core DWH schema, PXF/S3 integration, GPFDIST parallel load |
| | `database/clickhouse/` | Cluster DDL/DML, data marts, incremental upsert, verification queries, table blueprint |
| | `scripts/infrastructure/gp_segments_fault_recovery.sh` | Automatic detection and recovery of failed Greenplum segments |
| Semantic layer and BI | `cube/MvOeeCurrentMonth.js` | Cube semantic model for business metrics |
| | `helm/` | Kubernetes deployment template and Superset Helm values |
| | `docker/Dockerfile.analytics_base` | Base image for analytics components |
| Monitoring | `grafana/dashboards/database_observability.json` | Database monitoring dashboard |
| Data governance | `openmetadata/services/database/` | OpenMetadata service connections (Greenplum, ClickHouse) |
| Logging | `elasticsearch/queries/` | Log analysis queries (Kibana Dev Tools format, `.http`) |
| CI/CD | `.gitlab-ci.yml` | Pipeline for build, security scanning, and deployment |

## Technology Stack

Python, SQL, Bash, JavaScript, Airflow, Kafka, Greenplum, ClickHouse, PostgreSQL, S3, Cube, Superset, OpenMetadata, Grafana, Elasticsearch, Docker, Kubernetes/Helm, GitLab CI.

## License

TODO: add license information.
