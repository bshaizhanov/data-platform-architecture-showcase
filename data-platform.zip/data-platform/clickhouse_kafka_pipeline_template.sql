-- 1. RAW local table
CREATE TABLE locals.dbz_<entity>_raw_local
ON CLUSTER <cluster_name>
(
    insert_dt DateTime DEFAULT now(),
    raw String
)
ENGINE = ReplicatedMergeTree(
    '/clickhouse/tables/{shard}/{database}/{table}',
    '{replica}'
)
ORDER BY insert_dt
TTL insert_dt + toIntervalDay(30);
-- 2. RAW distributed table
CREATE TABLE kafka.dbz_<entity>_raw
ON CLUSTER <cluster_name>
AS locals.dbz_<entity>_raw_local
ENGINE = Distributed(
    '<cluster_name>',
    'locals',
    'dbz_<entity>_raw_local',
    rand()
);
-- 3. Kafka engine table
CREATE TABLE kafka.dbz_<entity>_kafka
ON CLUSTER <cluster_name>
(
    raw String
)
ENGINE = Kafka()
SETTINGS
    kafka_broker_list = '<broker_1>,<broker_2>,<broker_3>',
    kafka_topic_list = 'dbz.<domain>.<entity>',
    kafka_group_name = 'ch_<entity>',
    kafka_format = 'JSONAsString',
    kafka_num_consumers = 1,
    kafka_commit_every_batch = 1,
    kafka_commit_on_select = 1;
-- 4. MV Kafka -> RAW
CREATE MATERIALIZED VIEW kafka.mv_dbz_<entity>_raw
ON CLUSTER <cluster_name>
TO locals.dbz_<entity>_raw_local
AS
SELECT
    now() AS insert_dt,
    raw
FROM kafka.dbz_<entity>_kafka;
-- 5. Parsed local table
CREATE TABLE locals.dbz_<entity>_local
ON CLUSTER <cluster_name>
(
    id UInt64,
    attr_1 Nullable(String),
    attr_2 Nullable(String),
    attr_3 UInt32,
    __op LowCardinality(String),
    __ts_ms DateTime64(3),
    __src_ts_ms DateTime64(3),
    __lsn UInt64,
    __is_deleted UInt8
)
ENGINE = ReplicatedReplacingMergeTree(
    '/clickhouse/tables/{shard}/{database}/{table}',
    '{replica}',
    __lsn
)
ORDER BY (id);
-- 6. Parsed distributed table
CREATE TABLE target_schema.dbz_<entity>
ON CLUSTER <cluster_name>
AS locals.dbz_<entity>_local
ENGINE = Distributed(
    '<cluster_name>',
    'locals',
    'dbz_<entity>_local',
    cityHash64(id)
);
-- 7. MV RAW -> Parsed
CREATE MATERIALIZED VIEW kafka.mv_dbz_<entity>
ON CLUSTER <cluster_name>
TO locals.dbz_<entity>_local
AS
WITH
    JSONExtractString(raw, 'op') AS op,
    if(op = 'd', JSONExtractRaw(raw, 'before'), JSONExtractRaw(raw, 'after')) AS payload,
    JSONExtractRaw(raw, 'source') AS source
SELECT
    toUInt64(JSONExtractInt(payload, 'id')) AS id,
    nullIf(JSONExtractString(payload, 'attr_1'), '') AS attr_1,
    nullIf(JSONExtractString(payload, 'attr_2'), '') AS attr_2,
    toUInt32(JSONExtractInt(payload, 'attr_3')) AS attr_3,
    op AS __op,
    toDateTime64(JSONExtractInt(raw, 'ts_ms') / 1000.0, 3) AS __ts_ms,
    toDateTime64(JSONExtractInt(source, 'ts_ms') / 1000.0, 3) AS __src_ts_ms,
    toUInt64(ifNull(JSONExtractInt(source, 'lsn'), 0)) AS __lsn,
    toUInt8(op = 'd') AS __is_deleted
FROM locals.dbz_<entity>_raw_local
WHERE op IN ('r', 'c', 'u', 'd')
  AND (JSONHas(raw, 'after') OR JSONHas(raw, 'before'));
-- 8. Start consumer
SYSTEM START FETCHES kafka.dbz_<entity>_kafka;
