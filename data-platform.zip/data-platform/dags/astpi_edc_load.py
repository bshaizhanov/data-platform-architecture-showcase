"""Dag to load data from EDC API to Greenplum DWH."""
import logging
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Union
from airflow import DAG
from airflow.exceptions import AirflowSkipException
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from src.astpi_edc.settings import (
    API_CONN_ID,
    BATCH_SIZE,
    CORE_TABLE,
    HK_SA_COLUMNS,
    PARAM_CONFIGS,
    SA_TABLE,
    SA_TO_CORE_COLUMN_MAP,
    TIMEZONE,
)
from src.astpi_edc.utils import (
    build_core_upsert_sql,
    calc_begin_dt,
    calc_end_dt,
    execute_batched_insert,
    fetch_edc_data,
    get_api_token,
)
from src.common.definitions.gp_connections import GPDatabases
from src.common.definitions.load_state import LoadState, LoadStatus
from src.common.logging_utils import log_end, log_start
logger = logging.getLogger(__name__)
DEFAULT_ARGS: Dict[str, Any] = {
    "owner": "Shaižanov_B_M",
    "retries": 1,
    "retry_delay": timedelta(minutes=10),
}
def _get_max_dt(hook: PostgresHook, param_code: str, period_type: str) -> Union[date, None]:
    """Returns the maximum record date in the staging table for the given parameter.

    Args:
        hook: PostgresHook instance used to connect to the database.
        param_code: Parameter code.
        period_type: Period type ('Y', 'M', 'D').
    Returns:
        Maximum date, or None if there is no data.
    """
    sql = """
        SELECT MAX(
            CASE
                WHEN period_type = 'Y' THEN DATE_TRUNC('year', period_dt)::date
                WHEN period_type = 'M' THEN DATE_TRUNC('month', period_dt)::date
                ELSE period_dt::date
            END
        )
        FROM {table}
        WHERE param_code = %(param_code)s
          AND period_type = %(period_type)s
    """.format(table=CORE_TABLE)
    result = hook.get_first(
        sql,
        parameters={"param_code": param_code, "period_type": period_type},
    )
    if result and result[0] is not None:
        val = result[0]
        if isinstance(val, datetime):
            return val.date()
        if isinstance(val, date):
            return val
    return None
def load_data() -> None:
    """Main load function: fetches data from the API and inserts it into the SA staging table.
    For each parameter configuration (param_code + period_type):
        1. Determines the maximum date in the SA table.
        2. Calculates the extraction range.
        3. Fetches data from the EDC API.
        4. Accumulates all rows.
    Then performs a batch INSERT into the SA table using a single VALUES statement.
    """
    conn_params, token = get_api_token(API_CONN_ID)
    end_dt = calc_end_dt()
    hook = PostgresHook(postgres_conn_id=GPDatabases.get_connection_id("dwh").value.conn_id)
    all_rows: List[Dict[str, Any]] = []
    for cfg in PARAM_CONFIGS:
        max_dt = _get_max_dt(hook, cfg.param_code, cfg.period_type)
        begin_dt = calc_begin_dt(cfg.period_type, max_dt)
        logger.info(
            "Fetching param_code=%s period_type=%s begin=%s end=%s",
            cfg.param_code,
            cfg.period_type,
            begin_dt,
            end_dt,
        )
        rows = fetch_edc_data(conn_params, token, cfg.param_code, cfg.period_type, begin_dt, end_dt, TIMEZONE)
        logger.info("Got %d rows for %s / %s", len(rows), cfg.param_code, cfg.period_type)
        all_rows.extend(rows)
    if not all_rows:
        logger.info("No data to insert — skipping SA load.")
        raise AirflowSkipException("No data to insert")
    sa_columns = SA_TO_CORE_COLUMN_MAP.keys()
    rows_to_insert = [tuple(row.get(c) for c in sa_columns) for row in all_rows]
    conn = hook.get_conn()
    try:
        execute_batched_insert(conn, rows_to_insert, sa_columns, SA_TABLE, BATCH_SIZE)
        conn.commit()
        logger.info("SA load complete: %d rows inserted into %s", len(rows_to_insert), SA_TABLE)
    except Exception:
        conn.rollback()
        logger.exception("SA insert failed, transaction rolled back")
        raise
    finally:
        conn.close()
def load_core() -> None:
    """Loads data from the SA staging table into the core table using UPSERT logic.
    Calculates:
        - hk: UUID derived from the MD5 of the PK fields (paramCode, objCode, period_type, periodDt).
        - hash_diff: UUID derived from the MD5 of all fields, used to detect changes.
    Inserts only new records (by hash_diff). On an hk conflict, updates
    all fields, hash_diff, and update_dt.
    """
    hook = PostgresHook(postgres_conn_id=GPDatabases.get_connection_id("dwh").value.conn_id)
    upsert_sql = build_core_upsert_sql(SA_TO_CORE_COLUMN_MAP, HK_SA_COLUMNS, SA_TABLE, CORE_TABLE)
    logger.info("Running UPSERT from %s into %s", SA_TABLE, CORE_TABLE)
    conn = hook.get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(upsert_sql)
        conn.commit()
        logger.info("Core UPSERT complete for %s", CORE_TABLE)
    except Exception:
        conn.rollback()
        logger.exception("Core UPSERT failed, transaction rolled back")
        raise
    finally:
        conn.close()
with DAG(
    dag_id="astpi_edc_load",
    default_args=DEFAULT_ARGS,
    schedule_interval="0 8,20 * * *",
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["astpi", "edc", "dwh"],
) as dag:
    t_load_sa = PythonOperator(
        task_id="load_data",
        python_callable=load_data,
        on_execute_callback=log_start,
        on_success_callback=log_end(
            table_name="sa_astpi_edc",
            status=LoadStatus.SUCCESS,
            state=LoadState.LOADED_SA,
            schema_name="sa",
        ),
        on_failure_callback=log_end(
            table_name="sa_astpi_edc",
            status=LoadStatus.FAILED,
            state=LoadState.LOADED_SA,
            schema_name="sa",
        ),
    )
    t_load_core = PythonOperator(
        task_id="load_core",
        python_callable=load_core,
        on_execute_callback=log_start,
        on_success_callback=log_end(
            table_name="fct_astpi_edc",
            status=LoadStatus.SUCCESS,
            state=LoadState.LOADED_CORE,
            schema_name="core",
        ),
        on_failure_callback=log_end(
            table_name="fct_astpi_edc",
            status=LoadStatus.FAILED,
            state=LoadState.LOADED_CORE,
            schema_name="core",
        ),
    )
    t_load_sa >> t_load_core
