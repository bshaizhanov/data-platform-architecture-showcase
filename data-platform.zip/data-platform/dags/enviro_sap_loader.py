"""DAG for ETL of SAP BW Business tables from SA to Core."""
from functools import partial
from pathlib import Path
from typing import Union
import pendulum
from airflow import DAG
from airflow.models.baseoperator import chain
from airflow.operators.empty import EmptyOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.utils.task_group import TaskGroup
from airflow.utils.trigger_rule import TriggerRule
from src.common.alerting_utils import dag_success_alert, task_failure_alert
from src.common.definitions.load_state import LoadState, LoadStatus
from src.common.loader.sap_bw_loader import (
    DEFAULT_CONN_ID,
    SapBWDimLoader,
    SAPBWFactLoader,
)
from src.common.logging_utils import log_end, log_start
from src.common.utils import read_sql_file
from src.enviro import settings
default_args = {
    "owner": "Shaižanov_B_M",
    "depends_on_past": False,
    "retries": 0,
    "retry_delay": pendulum.duration(minutes=5),
}
# The list of system notification recipients is fully anonymized for security reasons
receiver_list = ["admin.placeholder@example.local", "dev.placeholder@example.local"]
task_failure_alert = partial(task_failure_alert, receiver_list=receiver_list)
dag_success_alert = partial(dag_success_alert, receiver_list=receiver_list)
with DAG(
    dag_id="enviro_sap_loader",
    description="ENVIRO DAG for load of tables from SAP BW",
    schedule_interval="0 9,13,22 * * *",
    start_date=pendulum.datetime(2024, 1, 1, tz=pendulum.timezone("Etc/GMT-5")),
    catchup=False,
    tags=["gp", "enviro", "sap"],
    max_active_tasks=1,
    max_active_runs=1,
    default_args=default_args,
    on_success_callback=dag_success_alert,
) as dag:
    previous_pipeline = None
    hook = PostgresHook(postgres_conn_id=DEFAULT_CONN_ID)
    loader: Union[SAPBWFactLoader, SapBWDimLoader]
    for open_hub_name, table_opts in settings.TABLES.items():
        table_business_name = str(table_opts.get("business_name", open_hub_name))
        if table_opts["is_fact"]:
            core_table_name = f"{settings.CORE_SCHEMA}.fct_{table_business_name}"
            loader = SAPBWFactLoader(
                hook=hook,
                open_hub_name=open_hub_name,
                core_table_name=core_table_name,
                sa_schema=settings.SA_SCHEMA,
                failure_reciever_list=receiver_list,
            )
            pipeline = loader.build()
            dag.get_task(f"{open_hub_name}_load.check_if_sa_loading").trigger_rule = TriggerRule.ALL_DONE
        else:
            loader = SapBWDimLoader(
                open_hub_name=open_hub_name,
                business_name=table_business_name,
                sa_schema=settings.SA_SCHEMA,
                core_schema=settings.CORE_SCHEMA,
                sql_path=settings.SQLS_PATH,
                failure_reciever_list=receiver_list,
            )
            pipeline = loader.build()
            dag.get_task(f"{open_hub_name}_load.check_if_sa_loading").trigger_rule = TriggerRule.ALL_DONE
        if previous_pipeline:
            pipeline.set_upstream(previous_pipeline)
        previous_pipeline = pipeline
    refresh_gate = EmptyOperator(
        task_id="refresh_gate",
        trigger_rule=TriggerRule.ALL_DONE,
    )
    with TaskGroup("core_to_dm_tables") as dm_tables_group:
        dm_tasks = []
        for table in settings.CORE_TO_DM_TABLES:
            load_to_dm = PostgresOperator(
                task_id=f"core_to_dm_{table}",
                postgres_conn_id=DEFAULT_CONN_ID,
                sql=read_sql_file(Path(settings.SQLS_PATH) / "core_to_dm" / f"{table}.sql"),
                trigger_rule=TriggerRule.ALL_DONE,
                on_success_callback=log_end(
                    table_name=table,
                    status=LoadStatus.SUCCESS,
                    state=LoadState.LOADED_DM,
                    schema_name=settings.DM_SCHEMA,
                ),
                on_execute_callback=log_start,
            )
            dm_tasks.append(load_to_dm)
        if dm_tasks:
            chain(*dm_tasks)
    with TaskGroup("refresh_matviews", tooltip="Refresh materialized views") as refresh_group:
        tasks = []
        for view in settings.MAT_VIEWS:
            refresh_task = PostgresOperator(
                task_id=f"refresh_{view}",
                postgres_conn_id=DEFAULT_CONN_ID,
                sql=f"REFRESH MATERIALIZED VIEW {settings.DM_SCHEMA}.{view};",
                trigger_rule=TriggerRule.ALL_DONE,
                on_success_callback=log_end(
                    table_name=f"matview_{view}",
                    status=LoadStatus.SUCCESS,
                    state=LoadState.REFRESHED,
                    schema_name=settings.DM_SCHEMA,
                ),
                on_execute_callback=log_start,
            )
            tasks.append(refresh_task)
        if tasks:
            chain(*tasks)
    if previous_pipeline:
        previous_pipeline >> refresh_gate
    else:
        pass
    refresh_gate >> dm_tables_group >> refresh_group
