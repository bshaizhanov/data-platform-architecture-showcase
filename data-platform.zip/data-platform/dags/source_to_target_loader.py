"""Airflow DAG for loading data from relational DB to analytical DB via object storage."""
import logging
import time
from datetime import datetime, timedelta
from typing import Any
from airflow import DAG
from airflow.exceptions import AirflowException
from airflow.models import Param
from airflow.operators.empty import EmptyOperator
from airflow.operators.python import BranchPythonOperator, PythonOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from apache.airflow.providers.clickhouse.hooks.ClickhouseHook import ClickhouseHook
from src.data_loader.settings import SCHEMA_MAPPING
from src.data_loader.utils.analytics_db import (
    add_cardinality_n_nullability,
    generate_target_ddl,
    generate_target_dml,
)
from src.data_loader.utils.source_db import (
    delete_by_prefix,
    generate_external_ddl,
    generate_external_dml,
    get_source_objects,
    get_object_columns,
)
logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)
def _validate_params(**context: Any) -> None:
    params = context["params"]
    reload_type = params.get("reload_type")
    date_from = params.get("reload_period_from")
    date_to = params.get("reload_period_to")
    reload_column = params.get("reload_column")
    target_schema = params.get("target_schema")
    if not target_schema:
        raise AirflowException("target_schema must not be empty")
    if reload_type == "NO_RELOAD":
        if not params.get("order_by"):
            raise AirflowException("order_by must not be empty")
        if not params.get("distribute_by"):
            raise AirflowException("distribute_by must not be empty")
        if reload_column or date_to or date_from:
            raise AirflowException("Period parameters must not be set for NO_RELOAD")

    elif reload_type == "RELOAD_PERIOD":
        if not date_from or not date_to or not reload_column:
            raise AirflowException("RELOAD_PERIOD requires a period and a column")
        if date_from > date_to:
            raise AirflowException("date_from must not be greater than date_to")
    elif reload_type == "FULL_RELOAD":
        if date_from or date_to:
            raise AirflowException("A period must not be set for FULL_RELOAD")
def _create_target_tables(**context: Any) -> None:
    params = context["params"]
    target_object = params.get("target_object")
    obj_type, obj_schema, obj_name = target_object.split(".")
    table_params = {
        "partition_by": params.get("partition_by"),
        "order_by": params.get("order_by"),
        "distribute_by": params.get("distribute_by"),
        "target_schema": params.get("target_schema"),
    }
    src_cols = get_object_columns(obj_schema, obj_name, obj_type)
    ready_cols = add_cardinality_n_nullability(obj_schema, obj_name, src_cols)
    local_ddl, dist_ddl = generate_target_ddl(obj_schema, obj_name, ready_cols, table_params)
    hook = ClickhouseHook("target_db_conn")
    hook.run(local_ddl)
    hook.run(dist_ddl)
    log.info("Target tables created")
def _create_external_table(**context: Any) -> str:
    params = context["params"]
    target_object = params.get("target_object")
    obj_type, obj_schema, obj_name = target_object.split(".")
    src_cols = get_object_columns(obj_schema, obj_name, obj_type)
    ext_ddl, ext_dml = generate_external_ddl(obj_schema, obj_name, src_cols)
    hook = PostgresHook(postgres_conn_id="source_db_conn")
    with hook.get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(ext_ddl)
    return ext_dml
def _insert_data_to_storage(**context: Any) -> None:
    params = context["params"]
    target_object = params.get("target_object")
    obj_type, obj_schema, obj_name = target_object.split(".")
    reload_type = params.get("reload_type")
    src_cols = get_object_columns(obj_schema, obj_name, obj_type)
    cols_str = ", ".join([f'"{col_name}"' for col_name, _ in src_cols])
    delete_by_prefix(f"data-transfer/{SCHEMA_MAPPING[obj_schema]}/{obj_name}")
    fmt_params = {
        "schema": obj_schema,
        "table": obj_name,
        "cols_str": cols_str,
        "reload_column": params.get("reload_column"),
        "date_from": params.get("reload_period_from"),
        "date_to": params.get("reload_period_to"),
    }
    ext_dml = generate_external_dml(reload_type).format(**fmt_params)
    hook = PostgresHook(postgres_conn_id="source_db_conn")
    with hook.get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(ext_dml)
def _load_data_to_target(**context: Any) -> None:
    params = context["params"]
    target_object = params.get("target_object")
    _, _, obj_name = target_object.split(".")
    reload_type = params.get("reload_type")
    hook = S3Hook(aws_conn_id="object_storage_conn", verify=False)
    creds = hook.get_credentials()
    fmt_params = {
        "schema": params.get("target_schema"),
        "table": obj_name,
        "access_key": creds.access_key,
        "secret_key": creds.secret_key,
        "reload_column": params.get("reload_column"),
        "date_from": params.get("reload_period_from"),
        "date_to": params.get("reload_period_to"),
    }
    insert_dml, delete_dml = generate_target_dml(reload_type)
    target_hook = ClickhouseHook("target_db_conn")
    if delete_dml:
        target_hook.run(delete_dml.format(**fmt_params))
        time.sleep(120)
    target_hook.run(insert_dml.format(**fmt_params))
def choose_path(**context: Any) -> str:
    reload_type = context["params"].get("reload_type")
    if reload_type != "NO_RELOAD":
        return "skip_table_creation"
    return "create_target_tables"
default_args = {
    "owner": "Shaižanov_B_M",
    "depends_on_past": False,
    "retries": 0,
    "retry_delay": timedelta(minutes=5),
}
with DAG(
    dag_id="source_to_target_loader",
    default_args=default_args,
    description="Load data from source DB to analytical DB",
    schedule_interval=None,
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["data-transfer"],
    params={
        "target_object": Param(
            default=None,
            type="string",
            enum=get_source_objects(),
            description="Select an object: type.schema.name",
        ),
        "target_schema": Param(
            default=None,
            type=["null", "string"],
            description="Table schema in the target database",
        ),
        "order_by": Param(default=None, type=["null", "string"]),
        "partition_by": Param(default=None, type=["null", "string"]),
        "distribute_by": Param(default="rand()", type=["null", "string"]),
        "reload_type": Param(
            default="NO_RELOAD",
            type=["null", "string"],
            enum=["NO_RELOAD", "FULL_RELOAD", "RELOAD_PERIOD"],
        ),
        "reload_column": Param(default=None, type=["null", "string"]),
        "reload_period_from": Param(default=None, type=["null", "string"], format="full-date"),
        "reload_period_to": Param(default=None, type=["null", "string"], format="full-date"),
    },
) as dag:
    validate_params = PythonOperator(
        task_id="validate_params",
        python_callable=_validate_params,
        provide_context=True,
    )
    create_target_tables = PythonOperator(
        task_id="create_target_tables",
        python_callable=_create_target_tables,
        provide_context=True,
    )
    create_external_table = PythonOperator(
        task_id="create_external_table",
        python_callable=_create_external_table,
        provide_context=True,
    )
    insert_to_storage = PythonOperator(
        task_id="insert_to_storage",
        python_callable=_insert_data_to_storage,
        provide_context=True,
        trigger_rule="none_failed_min_one_success",
    )
    load_to_target = PythonOperator(
        task_id="load_to_target",
        python_callable=_load_data_to_target,
        provide_context=True,
    )
    branch = BranchPythonOperator(task_id="branch_reload_type", python_callable=choose_path)
    skip_dummy = EmptyOperator(task_id="skip_table_creation")
    validate_params >> branch
    branch >> create_target_tables >> create_external_table >> insert_to_storage >> load_to_target
    branch >> skip_dummy >> create_external_table
